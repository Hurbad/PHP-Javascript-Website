<?php

echo '</main><section class="footer">';
echo  '<p>Created by: Abdiwahab Hersi';
echo '<br>  Contact information: <a href="mailto:AH1701@live.mdx.ac.uk">';
echo  'AH1701@live.mdx.ac.uk</a></p>';
echo '</section>';
echo '</body>';
echo '</html>';
?>
