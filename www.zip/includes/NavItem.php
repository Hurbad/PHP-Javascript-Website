<?php

//Nav item functions

$navItems = array(
            array(
                  "slug" => "game.php",
                  "title" => "Play",

            ),
            array(
                  "slug" => "ranking.php",
                  "title" => "Ranking",

            ),

            array(
                  "slug" => "About.php",
                  "title" => "About",

            ),
);




 ?>
