<?php
  include('includes/header.php');
?>


<title>Homepage</title>
<main style="background-color:;color:white;padding:20px;">

<center><h2>Trivia</h2>

 <p>There are three different difficulties depending on your skill level.</p>

<br>
Easy Difficulty:  Features Famous Logos
<br>
Medium Difficulty:  Features World Flags
<br>
Hard Difficulty:  Features World Map
</p>
</center>

<?php
include('includes/footer.php');
?>
