<?php
  include('includes/header.php');
?>

<title>About</title>
<center><main style="color:white;padding:25px;">
<strong><p>About</p></strong>
<p>
Website was designed by Abdiwahab I Hersi<br> M00621982
<br>
2nd Year Coursework
<br>
Languages used : PHP, JavaScript, CSS, HTML




</p>
</main>
</center>
<?php
  include('includes/footer.php');
?>
